console.clear();
/* -- */
require("console-stamp")(console, { format: ":date(HH:MM:ss).bold.grey" });
let chalk = require("chalk");
let _ = require("lodash")
const Discord = require("discord.js");
const config = require(`./botconfig/config.json`);
const fs = require('fs');
const yaml = require('yaml');
const lang = yaml.parse(fs.readFileSync("./botconfig/Lang.yml", 'utf-8'));
let Sconfig = yaml.parse(fs.readFileSync("./botconfig/Tickets.yml", 'utf-8'));
if (process.versions.node < 16.7) {
  console.log(chalk.bold.hex("#ff0000")("This bot requires node.js version 16.7 or Higher!"));
  process.exit(0);
}
if (parseFloat(Discord.version) < 13.6) {
  console.log(chalk.bold.redBright("[ERROR] ") + chalk.bold.hex("#ff0000")("This bot requires discord.js version 13.4 or Higher!"));
  process.exit(0);
}


/* -- */
const client = new Discord.Client({
  fetchAllMembers: false,
  restTimeOffset: 0,
  failIfNotExists: false,
  shards: "auto",
  allowedMentions: {
    parse: ["roles", "users"],
    repliedUser: false,
  },
  restRequestTimeout: 100000,
  partials: ['MESSAGE', 'CHANNEL', 'REACTION', 'GUILD_MEMBER', 'USER'],
  intents: [Discord.Intents.FLAGS.GUILDS,
  Discord.Intents.FLAGS.GUILD_MEMBERS,
  Discord.Intents.FLAGS.GUILD_BANS,
  Discord.Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS,
  Discord.Intents.FLAGS.GUILD_INTEGRATIONS,
  Discord.Intents.FLAGS.GUILD_WEBHOOKS,
  Discord.Intents.FLAGS.GUILD_INVITES,
  Discord.Intents.FLAGS.GUILD_VOICE_STATES,
  Discord.Intents.FLAGS.GUILD_PRESENCES,
  Discord.Intents.FLAGS.GUILD_MESSAGES,
  Discord.Intents.FLAGS.GUILD_MESSAGE_REACTIONS,
  //Discord.Intents.FLAGS.GUILD_MESSAGE_TYPING,
  Discord.Intents.FLAGS.DIRECT_MESSAGES,
  Discord.Intents.FLAGS.DIRECT_MESSAGE_REACTIONS,
    //Discord.Intents.FLAGS.DIRECT_MESSAGE_TYPING
  ]
});

client.setMaxListeners(0);
require('events').defaultMaxListeners = 0;


/* -- */
client.config = Sconfig;
client.lang = lang;
client.commands = new Discord.Collection();
client.cooldowns = new Discord.Collection();
client.aliases = new Discord.Collection();

require("./handlers/commands").init(client)
const handlers = ["events", "antiCrash"]
handlers.forEach(h => {
  require(`./handlers/${h}`)(client);
})

/* -- */
client.login(config.token).catch(err => {
  console.log(chalk.bold.redBright("[ERROR] ") + chalk.hex("#ffffff").bold(`${err.message}`));
})
