//Import Modules
const mainConfig = require(`../../botconfig/config.json`);
const { onCoolDown } = require("../../handlers/functions");
const Discord = require("discord.js");
const fs = require('fs');
let chalk = require("chalk");
const yaml = require('yaml');
module.exports = async (client, message) => {
  function logError(value, stack, prefix = "ERROR") {
    const long = stack.split("\n").map(m => m.length).sort((a, b) => b - a)[0];
    const lines = "━".repeat(long);
    console.log(`\n${chalk.red.bold(`[${prefix}]`)} ${chalk.bold(value)}\n${lines}\n${chalk.bold.hex("#fa4040")(stack)}\n${lines}`);
  }
  if (!message.guild || !message.channel || message.author.bot) return;
  if (message.channel.partial) await message.channel.fetch();
  if (message.partial) await message.fetch();
  let { guild, channel, member } = message;
  const prefix = mainConfig.prefix;
  const prefixRegex = new RegExp(`^(<@!?${client.user.id}>|${escapeRegex(prefix)})`);
  if (!prefixRegex.test(message.content)) return;
  const [, mPrefix] = message.content.match(prefixRegex);
  const args = message.content.slice(mPrefix.length).trim().split(/ +/).filter(Boolean);
  const cmd = args.length > 0 ? args.shift().toLowerCase() : null;
  let command = client.commands.get(cmd);
  if (!command) command = client.commands.get(client.aliases.get(cmd));
  if (command) {
    try {
      if (command.memberpermissions && command.memberpermissions.length > 0 && !message.member.permissions.has(command.memberpermissions)) {
        return message.reply({
          embeds: [new Discord.MessageEmbed()
            .setColor("#ff0000")
            .setFooter(client.user.tag, client.user.displayAvatarURL({ dynamic: true }))
            .setTitle("You can not run this command")
            .setDescription(`You need to have this permissions; \n> ${command.memberpermissions.join("`, ``")}`)]
        }).then(msg => setTimeout(() => {
          msg.delete().catch(e => console.log("Couldn't Delete --> Ignore".gray))
        }, 5000))
      }
      try {
        await command.run(client, message, args, args.join(" ").split("++").filter(Boolean), message.member, args.join(" "), prefix);
      } catch (e) {
        logError(e.toString(), e.stack, command.name.toUpperCase() + " " + "COMMAND ERROR")
        return message.channel.send(`An unexpected error occured while running the command ${command.name}`).catch(a => { })
      }

    } catch (error) {
      console.log(error);
    }
  }
}
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, `\\$&`);
}
//https://github.com/Tomato6966
