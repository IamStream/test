const Utils = require('../../handlers/functions')
module.exports = client => {
  Utils.logWarn(`Reconnceting at ${new Date()}.`, "RECONNECTING")
  // console.log(`Reconnceting at ${new Date()}.`.bgYellow.black)
}

