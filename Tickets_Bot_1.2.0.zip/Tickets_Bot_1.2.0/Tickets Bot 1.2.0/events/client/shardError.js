const Utils = require('../../handlers/functions')
module.exports = (client, error, id) => {
  Utils.logError(`|| Shard #${id} Errored`, "SHARD ERROR")
  // console.log("[SHARD ERROR] ".bold.red + `|| [${String(new Date).split(" ", 5).join(" ")}] || Shard #${id} Errored`)
}
