const Utils = require('../../handlers/functions')
module.exports = (client, id) => {
    Utils.logInfo(`|| Shard #${id} Is Ready!`, "SHARD READY");
}
