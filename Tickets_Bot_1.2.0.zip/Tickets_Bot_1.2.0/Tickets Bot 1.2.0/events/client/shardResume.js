const Utils = require('../../handlers/functions')
module.exports = (client, id, replayedEvents) => {
  Utils.logInfo(`|| Shard #${id} Resumed`, "SHARD RESUMED")
  // console.log("[SHARD RESUMED] ".bold.green + `|| [${String(new Date).split(" ", 5).join(" ")}] || Shard #${id} Resumed`)
}
