const Utils = require('../../handlers/functions')
module.exports = (client, error) => {
  Utils.logError(String(error), "ERROR")
  // console.log(String(error).red.dim)
}
