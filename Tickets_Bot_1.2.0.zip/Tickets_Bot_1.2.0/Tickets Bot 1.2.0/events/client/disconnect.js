const Utils = require('../../handlers/functions')
module.exports = client => {
  Utils.logWarn(`You have been disconnected at ${new Date()}.`.dim)
}

