const Utils = require('../../handlers/functions')
module.exports = (client, event, id) => {
  Utils.logError(`|| Shard #${id} Disconnected`, "SHARD DISCONNECT")
  // console.log("[SHARD DISCONNECT] ".bold.underline.red + `|| [${String(new Date).split(" ", 5).join(" ")}] || Shard #${id} Disconnected`)
}
