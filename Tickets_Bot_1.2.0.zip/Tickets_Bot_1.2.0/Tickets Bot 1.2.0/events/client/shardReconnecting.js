const Utils = require('../../handlers/functions')
module.exports = (client, id) => {
  Utils.logWarn(`|| Shard #${id} Reconnecting`, "SHARD RECONNECTING");
  // console.log("[SHARD RECONNECTING] ".bold.brightYellow + `||  [${String(new Date).split(" ", 5).join(" ")}] || Shard #${id} Reconnecting`)
}
