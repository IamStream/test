const Utils = require('../../handlers/functions')
module.exports = (client, rateLimitData) => {
    Utils.logWarn(rateLimitData.path + " | " + rateLimitData.timeout, "RATE LIMIT")
    // console.log("[RATE LIMIT]".red.bold + " " + rateLimitData.path + " | " + rateLimitData.timeout);
}

