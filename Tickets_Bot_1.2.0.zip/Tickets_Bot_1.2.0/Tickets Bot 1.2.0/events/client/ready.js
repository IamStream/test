const Discord = require('discord.js')
const config = require('../../botconfig/config.json')
const fs = require('fs');
const YAML = require('yaml');
let chalk = require("chalk");
let Utils = require("../../handlers/functions")
module.exports = (client) => {
  // console.log(chalk.yellow(chalk.bold("|") + "━".repeat(40) + chalk.bold("|")));
  console.log(chalk.bold.hex("#ff8400")(chalk.bold("|") + "-".repeat(40) + chalk.bold("|")));
  console.log(" ".repeat(13) + chalk.bold.hex("#009fff")(client.user.tag));
  console.log(" ".repeat(13) + chalk.bold.hex("#57ff6b")("BOT IS NOW READY"));
  console.log();
  console.log();
  console.log("◦ " + chalk.bold.hex("#ffffff")("Contact me on discord " + chalk.underline.hex("#e9ff00")("ElkinSantiana#0115") + "!"));
  console.log(chalk.bold.hex("#ff8400")(chalk.bold("|") + "-".repeat(40) + chalk.bold("|")));
  console.log(chalk.bold.underline.red("® ALL RIGHTS RESERVED!"));


  if (client.guilds.cache.size < 1) {
    Utils.logWarn("The bot is not in any guild, please add the bot to a guild before starting the process again...");
    Utils.logError("Process will end now", "NOT ENOUGH GUILDS");
    return process.exit(1);
  } else if (client.guilds.cache.size > 1) {
    Utils.logWarn("The bot should be in only one guild, Please leave all the other servers and start the process again!");
    Utils.logError("Process will end now", "TOO MANY GUILDS");
    return process.exit(1);
  }
  Utils.checkTicketsConfig();
  require("../../handlers/tickets")(client);
}
