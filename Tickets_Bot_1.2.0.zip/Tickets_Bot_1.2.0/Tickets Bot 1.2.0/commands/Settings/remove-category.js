const { MessageEmbed, MessageAttachment, Permissions, MessageFlags, MessageButton, MessageActionRow, createButtonCollector } = require("discord.js");
const Utils = require("../../handlers/functions");
const fs = require('fs');
const yaml = require('yaml');
let _ = require("lodash")
module.exports = {
    name: 'remove-category',
    category: 'Settings',
    description: '',
    aliases: '',
    usage: '',
    memberpermissions: ["ADMINISTRATOR"],

    run: async (client, message, args) => {
        let config = client.config;
        let { member, channel, guild } = message;
        let value = args.join(" ");
        let category = config.Categories.find(ca => ca.Name.toLowerCase() == value?.toLowerCase());
        if (!value || args.length < 1 || !category) {
            return channel.send({
                embeds: [new MessageEmbed()
                    .setAuthor({
                        name: member.user.username,
                        iconURL: member.user.displayAvatarURL({ dynamic: true })
                    })
                    .setColor("#2f3136")
                    .setTimestamp()
                    .setTitle("__Please mention a valid category to delete__")
                ]
            });
        };
        await _.remove(config.Categories, (ca) => {
            return ca.Name.toLowerCase() == category.Name.toLowerCase();
        })

        await fs.writeFileSync("./botconfig/Tickets.yml", yaml.stringify(config));
        await channel.send({
            embeds: [new MessageEmbed()
                .setDescription(`The category __\`${category.Name}\`__ was deleted!`)
                .setColor("#007bff")
                .setTimestamp()
            ]
        })
    }
};