const { MessageEmbed, MessageAttachment, Permissions, MessageFlags, MessageButton, MessageActionRow, createButtonCollector } = require("discord.js");
const Utils = require("../../handlers/functions");
const fs = require('fs');
const yaml = require('yaml');
let _ = require('lodash')

module.exports = {
    name: 'setup',
    category: 'Settings',
    description: '',
    aliases: '',
    usage: '',
    memberpermissions: ["ADMINISTRATOR"],

    run: async (client, message, args) => {
        let config = client.config;
        let { channel, guild, member } = message;

        let questions = [
            "What do you want to be the limit of tickets?",
            "What is the channel where transcripts will be send?",
            "What is the category for the opened tickets?",
            "What is the category for the closed tickets?",
            "Do you want tickets to get deleted when the user leaves the guild?",
        ]
        let number = 0;
        async function sendQuestion(i) {
            number += 1;
            let question = questions[i];
            let embed = new MessageEmbed()
                .setTitle(`• ${question}`)
                .setTimestamp()
                .setColor("#2f3136")
                .setFooter({
                    text: "To skip this step, just type \"skip\""
                })
            if (i == 0) {
                embed.setDescription(`This should be a number!`)
            }
            if (i == 4) {
                embed.setDescription("• Valid answers:\n__**Yes**__\n> Y\n> Yes\n> True\n\n__**No**__\n> N\n> No\n> False");
            }
            await channel.send({
                embeds: [embed]
            })

            let response = await Utils.waitForResponse(member.id, channel).catch(err => { return console.log(err) })
            if (!response) return;
            let content = response.content;
            if (!content) return sendQuestion(i);
            if (content.toLowerCase().startsWith("skip")) {
                if (i >= questions.length - 1) return completed();
                else return sendQuestion(++i);
            }
            if (i == 0) {
                let number = _.toSafeInteger(content);
                if (!number || number < 1) {
                    channel.send({
                        content: "Mention a valid number! (higher than 0)"
                    })
                    number += 1;
                    return sendQuestion(i);
                };
                config.Main.Limit = number;
            } else if (i == 1) {
                let Tchannel = await Utils.getChannelMSG(response, 0, "GUILD_TEXT", false);
                if (!Tchannel) {
                    channel.send({
                        content: "Mention a valid channel!"
                    })
                    number += 1;
                    return sendQuestion(i)
                };
                config.Main.TranscriptChannel = Tchannel.name;
            } else if (i == 2) {
                let category = await Utils.getChannelMSG(response, 0, "GUILD_CATEGORY", false);
                if (!category) {
                    channel.send({
                        content: "Mention valid category!"
                    })
                    number += 1;
                    return sendQuestion(i);
                }
                config.Main.DiscordCategories.Opened = category.name;
            } else if (i == 3) {
                let category = await Utils.getChannelMSG(response, 0, "GUILD_CATEGORY", false);
                if (!category) {
                    channel.send({
                        content: "Mention valid category!"
                    })
                    number += 1;
                    return sendQuestion(i);
                }
                config.Main.DiscordCategories.Closed = category.name;
            } else if (i == 4) {
                let y = ["y", "yes", "true"]
                let n = ["n", "no", "false"]
                if (y.includes(content.toLowerCase())) {
                    config.Main.DeleteOnLeave = true;
                } else if (n.includes(content.toLowerCase())) {
                    config.Main.DeleteOnLeave = false;
                } else {
                    channel.send({
                        content: "Mention a valid value!"
                    })
                    number += 1;
                    return sendQuestion(i);
                }
            }
            if (i >= questions.length - 1) return completed();
            else return sendQuestion(++i);
        }
        sendQuestion(0)
        async function completed() {
            channel.bulkDelete(number + number)
            try {
                await fs.writeFileSync("./botconfig/Tickets.yml", yaml.stringify(config));
                channel.send({
                    embeds: [new MessageEmbed()
                        .setTitle("All the changes have been saved!")
                        .setColor("#2f3136")
                        .setTimestamp()
                        .setAuthor({
                            name: member.user.tag,
                            iconURL: member.user.displayAvatarURL({ dyanmic: true })
                        })
                    ]
                })
            } catch (error) {
                console.dir(config)
            }
        }
    }
};