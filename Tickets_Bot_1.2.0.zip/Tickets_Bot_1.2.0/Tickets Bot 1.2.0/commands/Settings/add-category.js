const { MessageEmbed, MessageAttachment, Permissions, MessageFlags, MessageButton, MessageActionRow, createButtonCollector } = require("discord.js");
const Utils = require("../../handlers/functions");
const fs = require('fs');
const yaml = require('yaml');
const getEmojis = require("get-emojis-from-string")
module.exports = {
    name: 'add-category',
    category: 'Settings',
    description: '',
    aliases: '',
    usage: '',
    memberpermissions: ["ADMINISTRATOR"],

    run: async (client, message, args) => {
        let config = client.config;
        let { channel, member, guild } = message;
        let data = {
            Name: null,
            Emoji: null,
            Roles: [],
            DiscordCategory: null,
            Questions: []
        }
        let questions = [
            "What is the name name of the category?",
            "What is the emoji of the category?",
            "What are the support roles?",
            "What is the discord category for this category?",
            "What is the question"
        ]
        let number = 0;
        async function sendQuestion(i) {
            number += 1;
            let question = questions[i];
            let embed = new MessageEmbed()
                .setTitle(`• ${question}`)
                .setTimestamp()
                .setColor("#2f3136")
            if (i == 2) {
                embed.setDescription(`Mention all the roles, and separe them using a space`)
            }
            if (i >= 4) {
                question = questions[3];
                embed.setTitle(`• ${question} #${data.Questions.length + 1}`)
                embed.setDescription("Once you send all the questions, just enter **`finish`**")
            }
            await channel.send({
                embeds: [embed]
            })

            let response = await Utils.waitForResponse(member.id, channel).catch(err => { return console.log(err) })
            if (!response) return;
            let content = response.content;
            if (!content) return sendQuestion(i)
            if (i == 0) {
                let category = config.Categories.find(ca => ca.Name.toLowerCase() == content.toLowerCase())
                if (category) return sendQuestion(i);
                data.Name = content;
                return sendQuestion(++i);
            } else if (i == 1) {
                let emojis = getEmojis(content);
                if (emojis.length < 1) return sendQuestion(i);
                let emoji = emojis[0]
                if (emoji.type == "Default Emoji") {
                    data.Emoji = emoji.name;
                } else if (emoji.type == "Discord Emoji") {
                    let info = `<${emoji.animated ? "a" : ""}:${emoji.name}:${emoji.id}>`
                    data.Emoji = info;
                }
                return sendQuestion(++i);
            } else if (i == 2) {
                let roles = response.mentions.roles;
                if (roles.size < 1) return sendQuestion(i);
                let names = roles.map(r => { return r.name })
                data.Roles = names;
                return sendQuestion(++i);
            } else if (i == 3) {
                let category = await Utils.getChannel(content, guild, "GUILD_CATEGORY", false);
                if (!category) {
                    channel.send({
                        content: "That is not a valid guild category!"
                    })
                    number += 1;
                    return sendQuestion(i);
                }
                data.DiscordCategory = category.name;
            }
            else if (i >= 4) {
                if (content.toLowerCase().startsWith("finish")) return completed();
                data.Questions.push(content);
                return sendQuestion(++i);
            }
        }
        sendQuestion(0)
        async function completed() {
            channel.bulkDelete(number + number)

            let msg = await channel.send({
                embeds: [new MessageEmbed()
                    .setColor("#2f3136")
                    .setTimestamp()
                    .setTitle("Adding a new category...")
                    .addField("• Name", `> ${data.Name}`, true)
                    .addField("• Emoji", `> ${data.Emoji}`, true)
                    .addField("• Roles", `> ${data.Roles.length} Support Role(s)`, true)
                    .addField("• Discord Category", `> ${data.DiscordCategory}`, true)
                    .addField("• Questions", `> ${data.Questions.length} Question(s)`, true)
                ]
            })
            config.Categories.push(data);
            await fs.writeFileSync("./botconfig/Tickets.yml", yaml.stringify(config));
            let embed = msg.embeds[0];
            embed.title = "Category successfully added!"
            embed.color = "#00ff25"
            msg.edit({
                embeds: [embed]
            })
        }
    }
};