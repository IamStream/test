const { MessageEmbed, MessageAttachment, Permissions, MessageFlags, MessageButton, MessageActionRow, createButtonCollector } = require("discord.js");
const Utils = require("../../handlers/functions");
const fs = require('fs');
const chalk = require("chalk");
const yaml = require('yaml');
module.exports = {
    name: 'rebuild',
    cooldown: '',
    category: 'Settings',
    description: '',
    aliases: '',
    usage: '',
    memberpermissions: ["ADMINISTRATOR"],

    run: async (client, message, args) => {
        const lang = client.lang;
        let config = client.config;
        let db = require("better-sqlite3")(`./databases/tickets/Tickets.sqlite`);
        let { channel, guild, member } = message;
        let ticket;
        if (!args[0]) {
            ticket = await db.prepare("SELECT * FROM tickets WHERE guildID=? AND channelID=?").get(guild.id, channel.id)
            if (!ticket) return channel.send({
                // content: "You forgot to add a valid ticket channel ID and this is not a ticket channel",
                embeds: [new MessageEmbed()
                    .setTitle("This is not a ticket channel")
                    .setColor("#ff0000")
                    .setTimestamp()
                    .setDescription("Remember you can also use this command like this:\n> \`rebuild <TicketChannelID>\`")
                ]
            })
        } else {
            let fChannel = await Utils.getChannelMSG(message, 1, "GUILD_TEXT", false)
            ticket = await db.prepare("SELECT * FROM tickets WHERE guildID=? AND channelID=?").get(guild.id, fChannel?.id)

            if (!fChannel || !ticket) return channel.send({
                content: `I didn't find a valid ticket channel with the ID ${args[0]}!`
            })
        }
        let tChannel = await Utils.getChannel(ticket.channelID, guild, "GUILD_TEXT", true);
        if (!tChannel) return channel.send({
            content: `The channel with the id ${args[0]} was not found!`
        })
        let msg = await channel.send({
            embeds: [new MessageEmbed()
                .setTitle("Rebuilding ticket...")
                .setDescription("This might take a few seconds...")
                .setColor("#2f3136")
            ]
        })
        let rebuilded = await rebuildTicket(tChannel, ticket)
        if (rebuilded == true) {
            member.send({
                content: `✅ | The ticket <#${tChannel.id}> \`${tChannel.id}\` has been successfully rebuilded`
            }).catch(err => { })
            msg.edit({
                embeds: [new MessageEmbed()
                    .setTitle("Ticket has been successfully rebuilded")
                    .setColor("#00ff1f")
                    .setTimestamp()
                ]
            }).catch(err => { })
        } else if (rebuilded == false) {
            msg.edit({
                embeds: [new MessageEmbed()
                    .setTitle("Ticket could not be rebuilded!")
                    .setColor("#ff0000")
                    .setDescription(`Please check \`<#${tChannel.id}>\``)
                ]
            }).catch(err => { })
        }
        async function rebuildTicket(channel, ticket) {
            return new Promise(async (resolve, reject) => {
                try {
                    await channel.bulkDelete(60).catch(err => { })
                    let member = guild.members.cache.get(ticket.creatorID);
                    if (!member) {
                        channel.send({
                            content: "I can no re build this ticket because the creator of this ticket left the guild\n\n\`I recommend to delete this ticket\`"
                        })
                        return resolve(false)
                    }
                    let category = await Utils.getChannel(config.Main.DiscordCategories.Opened, guild, "GUILD_CATEGORY", false)
                    if (!category) {
                        Utils.logError(`I could'n find the category ${config.Main.DiscordCategories.Opened} in the guild ${guild.name}\nIf that category does not exits i can not create the ticket!`, "OPENED CATEGORY NOT FOUND")
                        channel.send({
                            content: "I can not reopen this ticket because there is not the opened category in this guild!"
                        })
                        return resolve(false)
                    }
                    await channel.permissionOverwrites.set([
                        {
                            id: guild.id,
                            deny: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
                        },
                        {
                            id: member.user.id,
                            allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
                        }
                    ]);
                    await channel.setParent(category);

                    const close = new MessageActionRow()
                        .addComponents([Utils.buttonBuilder({
                            button: lang.Tickets.DefaultButtons.Close,
                            id: "closeTicket"
                        })])
                    let formated = config.Categories.map(ca => {
                        return `${config.CategoryFormat
                            .replace(/{Emoji}/g, ca.Emoji ? ca.Emoji : "")
                            .replace(/{Name}/g, ca.Name)
                            .replace(/{Description}/g, ca.Description ? ca.Description.slice(0, 25) + "..." : "")
                            }`
                    })

                    let buttons = config.Categories.map(category => {
                        let button = Utils.buttonBuilder({
                            button: lang.Tickets.TicketMenu.CategoryButtonsStyle,
                            id: category.Name.toLowerCase(),
                            variables: [
                                { key: /{category-name}/g, value: category.Name },
                                { key: /{category-emoji}/g, value: category.Emoji },
                                { key: /{category-description}/g, value: category.Description ? category.Description.slice(0, 6) : "" }
                            ]
                        })
                        return button
                    })
                    let finalButtons = await Utils.formatButtons(buttons)
                    let tMessage = await channel.send({
                        embeds: Utils.embedBuilder(
                            lang.Tickets.TicketMenu.Embed,
                            [{ key: /{categories}/g, value: formated.join("\n") }],
                            {
                                member: [member, "member"],
                                guild: [guild, "guild"],
                                client: [client, "client"]
                            }),
                        components: [close, ...finalButtons]
                    })
                    await db.prepare("UPDATE tickets SET messageID=?, category=?, status=? WHERE guildID=? AND channelID=?").run(tMessage.id, null, 0, guild.id, channel.id);
                    // msg.delete().catch(err => { });
                    resolve(true)
                } catch (error) {
                    reject(error)
                }
            })
        }

    }
};