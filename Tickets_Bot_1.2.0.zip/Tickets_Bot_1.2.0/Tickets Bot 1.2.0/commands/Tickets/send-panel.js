const { MessageEmbed, MessageAttachment, Permissions, MessageFlags, MessageButton, MessageActionRow, createButtonCollector } = require("discord.js");
const Utils = require("../../handlers/functions");
const fs = require('fs');
const yaml = require('yaml');
module.exports = {
    name: 'send-panel',
    category: 'Settings',
    description: '',
    aliases: '',
    usage: '',
    memberpermissions: ["ADMINISTRATOR"],

    run: async (client, message, args) => {
        let lang = client.lang;
        let config = client.config;
        let { channel, guild, member } = message;
        // let row = new MessageActionRow()
        // let [button] = Utils.buttonBuilder({
        //     button: lang.Tickets.Panel.Button,
        //     id: "createTicket"
        // })
        // row.addComponents(button)

        // channel.send({
        //     embeds: Utils.embedBuilder(lang.Tickets.Panel.Embed, [], {
        //         guild: [guild, "guild"]
        //     }),
        //     components: [row]
        // })
        let buttons = new MessageActionRow()
            .addComponents(new MessageButton()
                .setCustomId("normalPanel")
                .setLabel("Normal")
                .setStyle("SECONDARY")
            )
            .addComponents(new MessageButton()
                .setCustomId("categorizedPanel")
                .setLabel("Categorized")
                .setStyle("SECONDARY")
            )
        let msg = await channel.send({
            embeds: [new MessageEmbed()
                .setTitle("What type of ticket panel do you want to send?")
                .setColor("BLURPLE")
                .addFields([
                    { name: "Normal", value: "> **One button to open a ticket**" },
                    { name: "Categorized", value: "> **All the categories in the main panel**" },
                ])
            ],
            components: [buttons]
        })
        let interaction = await Utils.waitForButton(["normalPanel", "categorizedPanel"], member.id, msg).catch(err => { })
        if (!interaction) return;
        let id = interaction.customId;
        interaction.deferUpdate();
        if (id == "normalPanel") {
            let row = new MessageActionRow()
            let [button] = Utils.buttonBuilder({
                button: lang.Tickets.Panel.Normal.Button,
                id: "createTicket"
            })
            row.addComponents(button)

            await channel.send({
                embeds: Utils.embedBuilder(lang.Tickets.Panel.Normal.Embed, [], {
                    guild: [guild, "guild"]
                }),
                components: [row]
            })
        } else if (id == "categorizedPanel") {
            let formated = config.Categories.map(ca => {
                return `${config.CategoryFormat
                    .replace(/{Emoji}/g, ca.Emoji ? ca.Emoji : "")
                    .replace(/{Name}/g, ca.Name)
                    .replace(/{Description}/g, ca.Description ? ca.Description : "")
                    }`
            })

            let buttons = config.Categories.map(category => {
                let button = Utils.buttonBuilder({
                    button: lang.Tickets.TicketMenu.CategoryButtonsStyle,
                    id: category.Name.toLowerCase(),
                    variables: [
                        { key: /{category-name}/g, value: category.Name },
                        { key: /{category-emoji}/g, value: category.Emoji },
                        { key: /{category-description}/g, value: category.Description ? category.Description.slice(0, 6) : "" }
                    ]
                })
                return button
            })
            let finalButtons = await Utils.formatButtons(buttons)
            channel.send({
                embeds: Utils.embedBuilder(lang.Tickets.Panel.Categorized, [
                    { key: /{categories}/g, value: formated.join("\n") }
                ], {
                    guild: [guild, "guild"],
                    client: [client, "client"]
                }),
                components: finalButtons
            })

        }
        msg.delete().catch(err => { })
    }
};