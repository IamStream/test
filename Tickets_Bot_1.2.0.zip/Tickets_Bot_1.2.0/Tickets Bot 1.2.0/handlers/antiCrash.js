let chalk = require("chalk");
let Utils = require("../handlers/functions");
module.exports = client => {
  function logError(value, stack, prefix = "ERROR") {
    const long = stack.split("\n").map(m => m.length).sort((a, b) => b - a)[0];
    const lines = "━".repeat(long);
    console.log(`\n${chalk.red.bold(`[${prefix}]`)} ${chalk.bold(value)}\n${lines}\n${chalk.bold.hex("#fa4040")(stack)}\n${lines}`);
    Utils.logWarn("IF you don't know how to solve this error, please contact me!", "ElkinSantiana#0115")
  }
  process.on('unhandledRejection', (reason, p) => {
    logError(reason.toString(), reason.stack, "Unhandled rejection/catch")
  })
  process.on('uncaughtException', (err, origin) => {
    logError(err.toString(), err.stack, "Uncaught exception/catch")
  })
  process.on('uncaughtExceptionMonitor', (err, origin) => {
    Utils.logError(err, "uncaughtExceptionMonitor")
  })
  process.on('multipleResolves', (type, promise, reason) => {
    console.log(type)
    Utils.logError(promise, "Multiple resolves")
  })
}
