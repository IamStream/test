const chalk = require("chalk");
const Discord = require('discord.js')
const fs = require('fs');
const yaml = require('yaml');
const { MessageEmbed, MessageAttachment, MessageFlags, MessageButton, MessageActionRow, createButtonCollector, MessageSelectMenu, Collection, Permissions, ClientPresence } = require('discord.js');
const { version } = require('discord.js');
const moment = require("moment");
let request = require(`request-promise`);
let _ = require("lodash");
const lang = yaml.parse(fs.readFileSync("./botconfig/Lang.yml", 'utf-8'));
let config = yaml.parse(fs.readFileSync("./botconfig/Tickets.yml", 'utf-8'));
module.exports = {
  logError: function (value, prefix = "ERROR") {
    console.log(chalk.hex("#f53434").bold(`[${prefix}]`) + " " + value)
  },
  logInfo: function (value, prefix = "INFO") {
    console.log(chalk.hex("#57ff6b").bold(`[${prefix}]`) + " " + value)
  },
  logWarn: function (value, prefix = "WARNING") {
    console.log(chalk.hex("#eeb603").bold(`[${prefix}]`) + " " + value)
  },
  transcript: require('./createTranscript.js'),
  waitForResponse: function (userid, channel) {
    return new Promise((resolve, reject) => {
      const filter = m => m.author.id == userid
      channel.awaitMessages({ filter, max: 1 }).then(msgs => {
        resolve(msgs.first());
      }).catch(reject)
    })
  },
  waitForReaction: function (emojis, UserIds, message) {
    return new Promise((resolve, reject) => {
      const filter = (reaction, user) => UserIds.includes(user.id) && emojis.includes(reaction.emoji.name)
      message.awaitReactions({ filter, max: 1 })
        .then(reaction => {
          resolve(reaction.first());
        }).catch(reject)
    })
  },
  waitForButton: function (ButtonIDs, UserIDs, message) {
    return new Promise((resolve, reject) => {
      if (!Array.isArray(ButtonIDs)) ButtonIDs = [ButtonIDs]
      if (!Array.isArray(UserIDs)) UserIDs = [UserIDs]
      const filter = (interaction) => UserIDs.includes(interaction.user.id) && ButtonIDs.includes(interaction.customId)
      message.awaitMessageComponent({ filter, max: 1 })
        .then(interaction => {
          resolve(interaction);
        }).catch(reject)
    })
  },
  waitForSelection: function (InteractionValues, UserIDs, message) {
    return new Promise((resolve, reject) => {
      if (!Array.isArray(InteractionValues)) InteractionValues = [InteractionValues]
      if (!Array.isArray(UserIDs)) UserIDs = [UserIDs]
      const filter = (interaction) => UserIDs.includes(interaction.user.id)
      message.awaitMessageComponent({ filter, max: 1, componentType: "SELECT_MENU" })
        .then(interaction => {
          resolve(interaction);
        }).catch(reject)
    })
  },
  getRole(value, guild, notification = true) {
    return new Promise(async (resolve, reject) => {
      try {
        let rol = guild.roles.cache.find(role => role.id == value || role.name.toLowerCase() == value.toLowerCase())
        if (!rol && notification) {
          this.logWarn(`The role ${value} was not found in the guild ${guild.name}`)
        }
        resolve(rol);
      } catch (error) {
        reject(error)
      }
    })
  },
  getChannel(value, guild, type = "GUILD_TEXT", notification = true) {
    return new Promise(async (resolve, reject) => {
      try {
        let types = ["GUILD_TEXT", "GUILD_CATEGORY", "GUILD_VOICE"]
        if (!types.includes(type.toUpperCase())) {
          this.logError(`Invalid channel type ${type}`)
          return resolve(false);
        }
        let channel = guild.channels.cache.find(ch => (ch.id == value || ch.name.toLowerCase() == value?.toLowerCase()) && ch.type.toUpperCase() == type?.toUpperCase())
        if (!channel && notification) {
          this.logWarn(`The channel ${value} was not found in the guild ${guild.name}`)
        }
        resolve(channel);
      } catch (error) {
        reject(error)
      }
    })
  },
  getChannelMSG(msg, arg = 0, type = "GUILD_TEXT", notification = true) {
    return new Promise(async (resolve, reject) => {
      try {
        const args = msg.content.slice().trim().split(/ +/).filter(Boolean);
        const text = (args[arg] || '');
        let types = ["GUILD_TEXT", "GUILD_CATEGORY", "GUILD_VOICE"]
        if (!types.includes(type.toUpperCase())) {
          this.logError(`Invalid channel type ${type}`)
          return resolve(false);
        }
        let ch = msg.guild.channels.cache.find(channel => channel.id == text.replace(/([<@]|[>])/g, '') || channel.name.toLowerCase() == text.toLowerCase() && type.toUpperCase() == type.toUpperCase()) || msg.mentions.channels.first()
        if (!ch && notification) {
          this.logWarn(`No channel was found in the message ${msg.id}`)
        }
        resolve(ch)
      } catch (error) {
        reject(error)
      }
    })
  },
  downloadAtts(attachments) {
    return new Promise(async (resolve, reject) => {
      try {
        let names = []
        for (let i = 0; i < attachments.size; i++) {
          let attch = attachments.at(i);
          let data = await request.get(attch.url).pipe(fs.createWriteStream(attch.name))
          names.push(data.path)
        }
        resolve(names)
      } catch (error) {
        reject(error)
      }
    })
  },
  /**
   * @typedef {Object} variable
   * @property {string} key - The key of the variable
   * @property {string} value - The value that the key will be replaced for
   */

  /**
   * @typedef {Object} defaults
   * @property {[Guild: Collection, prefix: string]} guild - Add guild variables.
   * @property {[Member: Collection, prefix: string]} member - Add member variables.
   * @property {[CLient: Collection, prefix: string]} client - Add client variables.
   */

  /**
   * Embed(s) builder.
   * @param {Object|Array.<object>} embeds Object or array of embeds to create
   * @param {Array.<variable>} variables The variables of the embeds
   * @param {defaults} normalVariables Defaults variables for the embeds
   */
  embedBuilder: function (settings, variables, normalVariables) {
    let Variables = [];
    if (variables && variables.length > 0) {
      variables.forEach(async (va) => {
        if (!va.key || !va.value) return;
        let data = {
          key: va.key,
          value: va.value
        }
        return Variables.push(data)
      })
    }
    if (normalVariables) {
      if (normalVariables.guild) {
        let guild = normalVariables.guild[0]
        let prefix = normalVariables.guild[1]
        Variables.push(...[
          { key: new RegExp(`{${prefix}-id}`, 'g'), value: guild.id },
          { key: new RegExp(`{${prefix}-name}`, 'g'), value: guild.name },
          { key: new RegExp(`{${prefix}-icon}`, 'g'), value: guild.iconURL({ dynamic: true }) ? guild.iconURL({ dynamic: true }) : "https://logos-marcas.com/wp-content/uploads/2020/12/Discord-Logo.png" },
        ])
      }
      if (normalVariables.member) {
        let member = normalVariables.member[0]
        let prefix = normalVariables.member[1]
        Variables.push(...[
          { key: new RegExp(`{${prefix}-id}`, 'g'), value: member.id },
          { key: new RegExp(`{${prefix}-username}`, 'g'), value: member.user.username },
          { key: new RegExp(`{${prefix}-tag}`, 'g'), value: member.user.tag },
          { key: new RegExp(`{${prefix}-icon}`, 'g'), value: member.user.displayAvatarURL({ dynamic: true }) ? member.user.displayAvatarURL({ dynamic: true }) : "https://logos-marcas.com/wp-content/uploads/2020/12/Discord-Logo.png" },
        ])
      }
      if (normalVariables.client) {
        let client = normalVariables.client[0]
        let prefix = normalVariables.client[1]
        Variables.push(...[
          { key: new RegExp(`{${prefix}-id}`, 'g'), value: client.id },
          { key: new RegExp(`{${prefix}-username}`, 'g'), value: client.user.username },
          { key: new RegExp(`{${prefix}-tag}`, 'g'), value: client.user.tag },
          { key: new RegExp(`{${prefix}-icon}`, 'g'), value: client.user.displayAvatarURL({ dynamic: true }) ? client.user.displayAvatarURL({ dynamic: true }) : "https://logos-marcas.com/wp-content/uploads/2020/12/Discord-Logo.png" },
        ])
      }
    }
    let embeds = [];
    if (_.isArray(settings) && settings.length > 0) {
      for (let i = 0; i < settings.length; i++) {
        let data = this.toLowerKeys(settings[i]);
        let keys = Object.keys(data);
        keys.forEach(async (key) => {
          if (_.isString(data[key])) {
            if (key == "thumbnail") {
              Variables.forEach(async (va) => {
                data[key] = data[key].replace(va.key, va.value)
              })
              data[key] = {
                url: data[key]
              }
            } else if (key == "image") {
              Variables.forEach(async (va) => {
                data[key] = data[key].replace(va.key, va.value)
              })
              data[key] = {
                url: data[key]
              }
            } else {
              Variables.forEach(async (va) => {
                data[key] = data[key].replace(va.key, va.value)
              })
            }
          } else if (key == "fields") {
            if (!_.isArray(data[key])) return;
            data[key].forEach(async (field, i) => {
              field = this.toLowerKeys(field);
              data[key][i] = this.toLowerKeys(data[key][i]);
              if (!field.name || !field.value) return;
              Variables.forEach(async (va) => {
                data[key][i].name = data[key][i].name.replace(va.key, va.value)
                data[key][i].value = data[key][i].value.replace(va.key, va.value)
              })
            })
          } else if (key == "author") {
            let author = {};
            data[key] = this.toLowerKeys(data[key]);
            let name = data[key].name;
            let iconURL = data[key].iconurl;
            Variables.forEach(async (va) => {
              if (name && _.isString(name)) name = name.replace(va.key, va.value)
              if (iconURL && _.isString(iconURL)) iconURL = iconURL.replace(va.key, va.value)
            })
            if (name && _.isString(name)) author.name = name
            if (iconURL && _.isString(iconURL)) author.iconURL = iconURL
            data[key] = author;
          } else if (key == "footer") {
            let footer = {};
            data[key] = this.toLowerKeys(data[key]);
            let text = data[key].text;
            let iconURL = data[key].iconurl;
            Variables.forEach(async (va) => {
              if (text && _.isString(text)) text = text.replace(va.key, va.value)
              if (iconURL && _.isString(iconURL)) iconURL = iconURL.replace(va.key, va.value)
            })
            if (text && _.isString(text)) footer.text = text;
            if (iconURL && _.isString(iconURL)) footer.iconURL = iconURL;
            data[key] = footer;
          } else if (key == "timestamp") {
            if (_.isBoolean(data[key]) && data[key] == true) {
              data[key] = new Date();
            } else data[key] = new Date(data[key]);
          }
        })
        embeds.push(data)
      }
    } else if (_.isObject(settings)) {
      let data = this.toLowerKeys(settings);
      let keys = Object.keys(data);
      keys.forEach(async (key) => {
        if (_.isString(data[key])) {
          if (key == "thumbnail") {
            Variables.forEach(async (va) => {
              data[key] = data[key].replace(va.key, va.value)
            })
            data[key] = {
              url: data[key]
            }
          } else if (key == "image") {
            Variables.forEach(async (va) => {
              data[key] = data[key].replace(va.key, va.value)
            })
            data[key] = {
              url: data[key]
            }
          } else {
            Variables.forEach(async (va) => {
              data[key] = data[key].replace(va.key, va.value)
            })
          }
        } else if (key == "fields") {
          if (!_.isArray(data[key])) return;
          data[key].forEach(async (field, i) => {
            field = this.toLowerKeys(field);
            data[key][i] = this.toLowerKeys(data[key][i]);
            if (!field.name || !field.value) return;
            Variables.forEach(async (va) => {
              data[key][i].name = data[key][i].name.replace(va.key, va.value)
              data[key][i].value = data[key][i].value.replace(va.key, va.value)
            })
          })
        } else if (key == "author") {
          let author = {};
          data[key] = this.toLowerKeys(data[key]);
          let name = data[key].name;
          let iconURL = data[key].iconurl;
          Variables.forEach(async (va) => {
            if (name && _.isString(name)) name = name.replace(va.key, va.value)
            if (iconURL && _.isString(iconURL)) iconURL = iconURL.replace(va.key, va.value)
          })
          if (name && _.isString(name)) author.name = name
          if (iconURL && _.isString(iconURL)) author.iconURL = iconURL
          data[key] = author;
        } else if (key == "footer") {
          let footer = {};
          data[key] = this.toLowerKeys(data[key]);
          let text = data[key].text;
          let iconURL = data[key].iconurl;
          Variables.forEach(async (va) => {
            if (text && _.isString(text)) text = text.replace(va.key, va.value)
            if (iconURL && _.isString(iconURL)) iconURL = iconURL.replace(va.key, va.value)
          })
          if (text && _.isString(text)) footer.text = text;
          if (iconURL && _.isString(iconURL)) footer.iconURL = iconURL;
          data[key] = footer;
        } else if (key == "timestamp") {
          if (_.isBoolean(data[key]) && data[key] == true) {
            data[key] = new Date();
          } else data[key] = new Date(data[key]);
        }
      })
      embeds.push(data)
    }
    return embeds;
  },
  buttonBuilder: function (settings = { button: {}, variables: [] }) {
    let ifUrl = new RegExp('^(https?:\\/\\/)?' +
      '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|' +
      '((\\d{1,3}\\.){3}\\d{1,3}))' +
      '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' +
      '(\\?[;&a-z\\d%_.~+=-]*)?' +
      '(\\#[-a-z\\d_]*)?$', 'i');
    let Variables = [];
    if (settings.variables && settings.variables.length > 0) {
      settings.variables.forEach(async (va) => {
        if (!va.key || !va.value) return;
        let data = {
          key: va.key,
          value: va.value
        }
        return Variables.push(data)
      })
    }
    settings = this.toLowerKeys(settings);
    let buttons = [];

    if (_.isArray(settings.button)) {
      for (let i = 0; i < settings.button.length; i++) {
        let data = settings.button[i];
        let button = new MessageButton();

        data = this.toLowerKeys(data);

        let id = settings.id || data.id
        let disabled = settings.disabled || data.disabled
        let emoji = settings.emoji || data.emoji
        let label = settings.label || data.label
        let style = settings.style || data.style
        let url = settings.url || data.url
        Variables.forEach(va => {
          if (id) id = id.replace(va.key, va.value)
          if (label) label = label.replace(va.key, va.value)
          if (url) url = url.replace(va.key, va.value)
          if (emoji) emoji = emoji.replace(va.key, va.value)
        })

        if (!style || (!emoji && !label) || (!style && !emoji && !label)) {
          button.setLabel("Button require more values!")
          button.setStyle("DANGER")
          button.setCustomId("Error-Builder")
          buttons.push(button);
          break;
        }

        // if (id) button.setCustomId(id)
        if (disabled) button.setDisabled(disabled)
        if (emoji) button.setEmoji(emoji)
        if (label) button.setLabel(label)

        if (style.toLowerCase() == "link") {
          if (!url || !_.isString(url) || !ifUrl.test(url)) {
            this.logError("LINK button types requires an valid URL!")
            button.setLabel("Button Type URL needs URL")
            button.setStyle("DANGER")
            buttons.push(button)
            break;
          }
          button.setStyle("LINK")
          button.setURL(url)
          buttons.push(button)
        } else {
          if (!id) {
            this.logError("Non LINK button type requires an ID!")
            button.setCustomId("Error-Builder").setStyle("DANGER").setLabel("NO ID specified!")
            buttons.push(button)
            break;
          }
          button.setCustomId(id)
          let styles = ["PRIMARY", "SECONDARY", "SUCCESS", "DANGER"]
          if (!styles.includes(style.toUpperCase())) {
            this.logWarn("You specified a Invalid button style, so i set it to SECONDARY")
            button.setStyle("SECONDARY")
          } else button.setStyle(style.toUpperCase())
          buttons.push(button)
        }

      }
      return buttons;
    } else if (_.isObject(settings.button)) {
      let data = settings.button;
      let button = new MessageButton();

      data = this.toLowerKeys(data);
      let id = settings.id || data.id
      let disabled = settings.disabled || data.disabled
      let emoji = settings.emoji || data.emoji
      let label = settings.label || data.label
      let style = settings.style || data.style
      let url = settings.url || data.url
      Variables.forEach(va => {
        if (id) id = id.replace(va.key, va.value)
        if (label) label = label.replace(va.key, va.value)
        if (url) url = url.replace(va.key, va.value)
        if (emoji) emoji = emoji.replace(va.key, va.value)
      })

      if (!style || (!emoji && !label) || (!style && !emoji && !label)) {
        button.setLabel("Button require more values!")
        button.setStyle("DANGER")
        button.setCustomId("Error-Builder")
        buttons.push(button);
        return buttons;
      }

      // if (id) button.setCustomId(id)
      if (disabled) button.setDisabled(disabled)
      if (emoji) button.setEmoji(emoji)
      if (label) button.setLabel(label)

      if (style.toLowerCase() == "link") {
        if (!url || !_.isString(url) || !ifUrl.test(url)) {
          this.logError("LINK button types requires an valid URL!")
          button.setLabel("Button Type URL needs URL")
          button.setStyle("DANGER")
          buttons.push(button)
          return buttons;;
        }
        button.setStyle("LINK")
        button.setURL(url)
        buttons.push(button)
      } else {
        if (!id) {
          this.logError("Non LINK button type requires an ID!")
          button.setCustomId("Error-Builder").setStyle("DANGER").setLabel("NO ID specified!")
          buttons.push(button)
          return buttons;
        }
        button.setCustomId(id)
        let styles = ["PRIMARY", "SECONDARY", "SUCCESS", "DANGER"]
        if (!styles.includes(style.toUpperCase())) {
          this.logWarn("You specified a Invalid button style, so i set it to SECONDARY")
          button.setStyle("SECONDARY")
        } else button.setStyle(style.toUpperCase())
        buttons.push(button)
      }
      return buttons
    }
  },
  toLowerKeys(obj) {
    return Object.keys(obj).reduce((accumulator, key) => {
      accumulator[key.toLowerCase()] = obj[key];
      return accumulator;
    }, {});
  },
  getFormatedNumber(number) {
    const num = parseInt(number);
    return ('0'.repeat(4 - num.toString().length)) + num;
  },
  formatButtons: function (components) {
    const rows = {
      1: new MessageActionRow(),
      2: new MessageActionRow(),
      3: new MessageActionRow(),
      4: new MessageActionRow(),
      5: new MessageActionRow()
    }
    let finalComponents = [];
    let y = 0;
    async function addComponents(i) {
      let row = rows[i]
      let component = components[y]
      row.addComponents(component)
      if (y == (components.length - 1)) return completed()
      y = ++y
      if (row.components.length == 5) return addComponents(++i)
      else addComponents(i)
    }
    addComponents(1)
    async function completed() {
      for (let x = 1; x <= 5; x++) {
        if (rows[x].components.length > 0 && rows[x].components.length <= 5) {
          finalComponents.push(rows[x])
        }
      }
    }
    return finalComponents;
  },
  restartTickets: function (client) {
    return new Promise(async (resolve, reject) => {
      try {
        if (_.isArray(client._events.interactionCreate)) {
          console.log(client._events.interactionCreate);
          await client.removeListener("interactionCreate", client._events.interactionCreate[0])
        } else await client.removeListener("interactionCreate", client._events.interactionCreate)

        if (_.isArray(client._events.channelDelete)) {
          await client.removeListener("channelDelete", client._events.channelDelete[0])
        } else await client.removeListener("channelDelete", client._events.channelDelete)


        if (client._events.guildMemberRemove) {
          if (_.isArray(client._events.guildMemberRemove)) {
            await client.removeListener("guildMemberRemove", client._events.guildMemberRemove[0])
          } else await client.removeListener("guildMemberRemove", client._events.guildMemberRemove)
        }
        delete require.cache[require.resolve(`./tickets`)];
        delete require.cache[require.resolve(`../botconfig/Lang.yml`)];
        delete require.cache[require.resolve(`../botconfig/Tickets.yml`)];
        require("./tickets")(client);
        resolve(true);
      } catch (error) {
        reject(error);
      }
    })
  },
  checkTicketsConfig: function () {
    let objs = ["Main", "Main.DiscordCategories"];
    let arrays = ["Categories"];
    let numbers = ["Main.Limit"];
    let strings = ["CategoryFormat", "AnswersFormat", "Main.TranscriptChannel", "Main.DiscordCategories.Opened", "Main.DiscordCategories.Closed"];
    let booleans = ["Main.DeleteOnLeave"];

    //Check objects
    objs.forEach(async (obj) => {
      let data = _.get(config, obj)
      if (!data || !_.isObject(data)) return this.logError(`The ${obj} key must be an object | It is ${chalk.bold.hex("#6f74df")(typeof data)}!`, "Tickets.yml")
    })

    //Check arrays
    arrays.forEach(async (array) => {
      let data = _.get(config, array)
      if (!data || !_.isArray(data)) return this.logError(`The ${array} key must be an array | It is ${chalk.bold.hex("#6f74df")(typeof data)}!`, "Tickets.yml")
    })

    //Check numbers
    numbers.forEach(async (number) => {
      let data = _.get(config, number)
      if (!data || !_.isNumber(data)) return this.logError(`The ${number} key must be a number | It is ${chalk.bold.hex("#6f74df")(typeof data)}!`, "Tickets.yml")
    })

    //Check strigns
    strings.forEach(async (string) => {
      let data = _.get(config, string)
      if (!data || !_.isString(data)) return this.logError(`The ${string} key must be a string | It is ${chalk.bold.hex("#6f74df")(typeof data)}!`, "Tickets.yml")
    })

    //Check booleans
    booleans.forEach(async (boolean) => {
      let data = _.get(config, boolean)
      if (!data || !_.isBoolean(data)) return this.logError(`The ${boolean} key must be boolean | It is ${chalk.bold.hex("#6f74df")(typeof data)}!`, "Tickets.yml")
    })
  }
}
