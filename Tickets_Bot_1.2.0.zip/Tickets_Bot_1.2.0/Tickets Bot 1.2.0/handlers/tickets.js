let Utils = require('./functions')
const { MessageEmbed, MessageAttachment, MessageFlags, MessageButton, MessageActionRow, createButtonCollector, MessageSelectMenu, Collection, Permissions, ClientPresence } = require("discord.js");
const fs = require('fs');
const chalk = require("chalk");
const yaml = require('yaml');
const lang = yaml.parse(fs.readFileSync("./botconfig/Lang.yml", 'utf-8'));
let _ = require('lodash');
let db = require("better-sqlite3")(`./databases/tickets/Tickets.sqlite`);
const numbers = require('number-to-emoji');
module.exports = async (client) => {
    let config = client.config;
    Utils.logInfo("Ticket system has been loaded", "TICKETS")
    db.prepare('CREATE TABLE IF NOT EXISTS tickets (ID INTEGER PRIMARY KEY AUTOINCREMENT, channelID TEXT, guildID TEXT, messageID TEXT, creatorID TEXT, createdAt INTEGER, closedAt INTEGER, category TEXT, status INTEGER)').run()

    /* ------------------------------------------------------------
                            Client events
    ------------------------------------------------------------ */
    client.on("interactionCreate", async (interaction) => {
        let { member, guild, channel, message } = interaction;
        if (!guild || !channel || !member || member.user.bot) return;
        let id = interaction.customId;
        switch (id) {
            case "createTicket": {
                createTicket(interaction)
                break;
            }
            case "closeTicket": {
                closeTicketInteraction(interaction)
                break;
            }
            case "reopenTicket": {
                reopenTicketInteraction(interaction)
                break;
            }
            case "deleteTicket": {
                deleteTicketInteraction(interaction)
                break;
            }
            case "createTranscript": {
                createTranscriptInteraction(interaction)
                break;
            }
            default: {
                let isTicket = db.prepare("SELECT * FROM tickets WHERE channelID=? AND status=?").get(channel.id, 0)
                if (isTicket) {
                    if (!message.id == isTicket.messageID) return;
                    if (isTicket.category) return;
                    setCategory(isTicket, id, interaction)
                } else {
                    let category = config.Categories.find(a => a.Name.toLowerCase() == id.toLowerCase());
                    if (!category) return;
                    let openedTickets = await db.prepare("SELECT * FROM tickets WHERE guildID=? AND creatorID=? AND status=?").all(guild.id, member.id, 0)
                    if (openedTickets.length >= config.Main.Limit) {
                        return interaction.reply({
                            embeds: Utils.embedBuilder(lang.Tickets.LimitReached, [], {
                                member: [member, "member"],
                                guild: [guild, "guild"]
                            }),
                            ephemeral: true
                        })
                    }
                    createTicketAndSetCategory(interaction, category);
                }
            }
        }
    })
    client.on("channelDelete", channel => {
        let { guild } = channel;
        let isTicket = db.prepare("SELECT * FROM tickets WHERE channelID=? AND status=? OR channelID=? AND status=?").get(channel.id, 0, channel.id, 1)
        if (!isTicket) return;
        closeTicket(channel)
    })
    if (config.Main.DeleteOnLeave) {
        client.on("guildMemberRemove", member => {
            let { guild } = member;
            let tickets = db.prepare('SELECT * FROM tickets WHERE creatorID=? AND status=? AND guildID=? OR creatorID=? AND status=? AND guildID=?').all(member.id, 0, guild.id, member.id, 1, guild.id)
            if (tickets.length < 1) return;
            tickets.forEach(ticket => {
                let channel = guild.channels.cache.get(ticket.channelID)
                if (!channel) return checkTickets();
                if (tickets.length == 1) Utils.logWarn(`ID: ${ticket.ID} Only a ticket was delete | User: ${member.user.id}`, "USER LEFT (1 Opened Ticket)")
                else Utils.logWarn(`ID: ${ticket.ID} Total Deleted Tickets: ${tickets.size} User: ${member.user.id}`, `[USER LEFT (${tickets.length} Opened Tickets)]`)
                channel.delete().catch(err => { })
            })
        })
    }

    /* ------------------------------------------------------------
                       Ticket and events functions
    ------------------------------------------------------------ */
    async function createTicket(interaction) {
        let { member, channel, guild, message } = interaction;
        let openedTickets = await db.prepare("SELECT * FROM tickets WHERE guildID=? AND creatorID=? AND status=?").all(guild.id, member.id, 0)
        if (openedTickets.length >= config.Main.Limit) {
            return interaction.reply({
                embeds: Utils.embedBuilder(lang.Tickets.LimitReached, [], {
                    member: [member, "member"],
                    guild: [guild, "guild"]
                }),
                ephemeral: true
            })
        }
        let category = await Utils.getChannel(config.Main.DiscordCategories.Opened, guild, "GUILD_CATEGORY", false)
        if (!category) {
            Utils.logError(`I could'n find the category ${config.Main.DiscordCategories.Opened} in the guild ${guild.name}\nIf that category does not exits i can not create the ticket!`, "OPENED CATEGORY NOT FOUND")
            // console.log(chalk.bold.red(`I could'n find the category ${config.Main.DiscordCategories.Opened} in the guild ${guild.name}\nIf that category does not exits i can not create the ticket!`))
            return interaction.reply({
                content: "I can not find the opened category in this guild, so please contact an administrator!",
                ephemeral: true
            })
        }
        let tickets = await db.prepare("SELECT * FROM tickets").all()
        let number = Utils.getFormatedNumber(tickets.length + 1)
        let tChannel = await guild.channels.create(`ticket-${number}`, {
            permissionOverwrites: [{
                id: guild.id,
                deny: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
            },
            {
                id: member.user.id,
                allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
            }
            ],
            parent: category,
        })
        const close = new MessageActionRow()
            .addComponents([Utils.buttonBuilder({
                button: lang.Tickets.DefaultButtons.Close,
                id: "closeTicket"
            })])
        let formated = config.Categories.map(ca => {
            return `${config.CategoryFormat
                .replace(/{Emoji}/g, ca.Emoji ? ca.Emoji : "")
                .replace(/{Name}/g, ca.Name)
                .replace(/{Description}/g, ca.Description ? ca.Description.slice(0, 25) + "..." : "")
                }`
        })

        let buttons = config.Categories.map(category => {
            let button = Utils.buttonBuilder({
                button: lang.Tickets.TicketMenu.CategoryButtonsStyle,
                id: category.Name.toLowerCase(),
                variables: [
                    { key: /{category-name}/g, value: category.Name },
                    { key: /{category-emoji}/g, value: category.Emoji },
                    { key: /{category-description}/g, value: category.Description ? category.Description.slice(0, 6) : "" }
                ]
            })
            return button
        })
        let finalButtons = await Utils.formatButtons(buttons)
        let tMessage = await tChannel.send({
            embeds: Utils.embedBuilder(
                lang.Tickets.TicketMenu.Embed,
                [{ key: /{categories}/g, value: formated.join("\n") }],
                {
                    member: [member, "member"],
                    guild: [guild, "guild"],
                    client: [client, "client"]
                }),
            components: [close, ...finalButtons]
        })

        let goRow = new MessageActionRow()
        let [goButton] = Utils.buttonBuilder({
            id: "goToTicket",
            button: lang.Tickets.TicketCreated.Button,
            variables: [
                { key: /{ticket-name}/g, value: tChannel.name },
                { key: /{ticket-url}/g, value: tMessage.url },
            ]
        })
        goRow.addComponents(goButton)

        interaction.reply({
            embeds: Utils.embedBuilder(lang.Tickets.TicketCreated.Embed, [], {
                guild: [guild, "guild"],
                member: [member, "member"],
            }),
            components: [goRow],
            ephemeral: true
        })

        await db.prepare(`INSERT INTO tickets VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(null, tChannel.id, guild.id, tMessage.id, member.id, Math.round(new Date().getTime() / 1000), null, null, 0)
    }
    async function createTicketAndSetCategory(interaction, category) {
        let { channel, guild, member } = interaction;
        let discordC = await Utils.getChannel(category?.DiscordCategory, guild, "GUILD_CATEGORY", true);
        if (!discordC) {
            Utils.logError(`I could'n find the category ${category?.DiscordCategory} in the guild ${guild.name} | If that category does not exits i can not create the ticket!`, "DISCORD CATEGORY NOT FOUND")
            // console.log(chalk.bold.red(`I could'n find the category ${config.Main.DiscordCategories.Opened} in the guild ${guild.name}\nIf that category does not exits i can not create the ticket!`))
            return interaction.reply({
                content: "I can not find the discord category from this category selected before in this guild, so please contact an administrator!",
                ephemeral: true
            })
        }
        let tickets = await db.prepare("SELECT * FROM tickets").all()
        let number = Utils.getFormatedNumber(tickets.length + 1)
        let Support = "";
        let permissions = [
            {
                id: guild.id,
                deny: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
            },
            {
                id: member.user.id,
                allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
            }
        ];
        category.Roles.forEach(async (r) => {
            let role = await Utils.getRole(r, guild, true)
            if (role) {
                Support += ` <@&${role.id}>`
                permissions.push({
                    id: role.id,
                    allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
                })
            }
        })
        let tChannel = await guild.channels.create(`ticket-${number}`, {
            permissionOverwrites: permissions,
            parent: discordC,
        })
        let goRow = new MessageActionRow()
        let [goButton] = Utils.buttonBuilder({
            id: "goToTicket",
            button: lang.Tickets.TicketCreated.Button,
            variables: [
                { key: /{ticket-name}/g, value: tChannel.name },
                { key: /{ticket-url}/g, value: `https://discord.com/channels/${guild.id}/${tChannel.id}` },
            ]
        })
        goRow.addComponents(goButton)

        interaction.reply({
            embeds: Utils.embedBuilder(lang.Tickets.TicketCreated.Embed, [], {
                guild: [guild, "guild"],
                member: [member, "member"],
            }),
            components: [goRow],
            ephemeral: true
        })
        await db.prepare(`INSERT INTO tickets VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(null, tChannel.id, guild.id, null, member.id, Math.round(new Date().getTime() / 1000), null, category.Name, 0)
        askQuestions(category, interaction, Support, tChannel)
    }
    async function closeTicketInteraction(interaction) {
        let { member, guild, channel, message } = interaction;
        let isTicket = await db.prepare("SELECT * FROM tickets WHERE channelID=?").get(channel.id)
        if (!isTicket) {
            interaction.deferUpdate()
            return channel.send({
                content: "This channel / ticket is not in my BD\n\n> **Deleting channel... 5 Second(s)**"
            }).then(msg => {
                setTimeout(() => {
                    channel.delete().catch(err => { })
                }, 5000)
            })
        }
        if (isTicket.status == 1) {
            return interaction.reply({
                ephemeral: true,
                content: ":x: | This ticket is already closed"
            })
        }
        interaction.deferUpdate()
        let creator = interaction.guild.members.cache.get(isTicket.creatorID)
        if (creator) await channel.permissionOverwrites.delete(creator);
        let category = await Utils.getChannel(config.Main.DiscordCategories.Closed, guild, "GUILD_CATEGORY", false)
        if (!category) {
            Utils.logError(`The category ${config.Main.DiscordCategories.Closed} does not exist in the guild ${guild.name}`, "CLOSED CATEGORY NOT FOUND");
            return channel.send({
                content: `I can not close this ticket because the category ${config.Main.DiscordCategories.Closed} does not exists in this guild!\n**The creator was remove from this channel**`
            })
        }
        await channel.setParent(category.id, { lockPermissions: false })
        let components = new MessageActionRow()
            .addComponents(Utils.buttonBuilder({
                button: lang.Tickets.DefaultButtons.Reopen,
                id: "reopenTicket"
            }))
            .addComponents(Utils.buttonBuilder({
                button: lang.Tickets.DefaultButtons.Delete,
                id: "deleteTicket"
            }))
            .addComponents(Utils.buttonBuilder({
                button: lang.Tickets.DefaultButtons.CreateTranscript,
                id: "createTranscript"
            }))
        await channel.send({
            embeds: Utils.embedBuilder(lang.Tickets.TicketClosed, [], {
                guild: [guild, "guild"],
                member: [member, "member"]
            })
        })
        await channel.send({
            embeds: Utils.embedBuilder(lang.Tickets.ControlPanel, [], {
                guild: [guild, "guild"],
                member: [member, "member"]
            }),
            components: [components]
        })
        await db.prepare("UPDATE tickets set status=? WHERE channelID=? AND status=?").run(1, channel.id, 0)
    }
    async function reopenTicketInteraction(interaction) {
        let { member, guild, channel, message } = interaction
        let isTicket = db.prepare("SELECT * FROM tickets WHERE channelID=? AND status=?").get(channel.id, 1)
        if (!isTicket) return;
        let user = guild.members.cache.get(isTicket.creatorID)
        if (!user) {
            return interaction.reply({
                content: "I can not reopen this ticket because the creator left the server!\n\n> **I recommend to delete this ticket**",
                ephemeral: true
            })
        }
        interaction.deferUpdate()
        await channel.permissionOverwrites.create(user.id, {
            VIEW_CHANNEL: true,
            READ_MESSAGE_HISTORY: true,
            SEND_MESSAGES: true,
            EMBED_LINKS: true,
            ATTACH_FILES: true
        })
        let discordC;
        let category = config.Categories.find(ca => ca.Name.toLowerCase() == isTicket?.category?.toLowerCase());
        if (!category) discordC = await Utils.getChannel(config.Main.DiscordCategories.Opened, guild, "GUILD_CATEGORY", true);
        else discordC = await Utils.getChannel(category.DiscordCategory, guild, "GUILD_CATEGORY", true);

        if (!discordC) return channel.send({
            content: "I can not reopen this ticket, because i didn't find the opened category or the Discord category from the selected category"
        })
        await channel.setParent(discordC.id, { lockPermissions: false })
        interaction.message.delete().catch(err => { })
        let msg = await channel.send({ content: `<@${user.id}>` })
        await channel.send({
            embeds: Utils.embedBuilder(lang.Tickets.TicketReopened, [], {
                guild: [guild, "guild"],
                member: [member, "member"],
            })
        })
        msg.delete().catch(err => { })
        await db.prepare("UPDATE tickets SET status=? WHERE channelID=? AND status=?").run(0, channel.id, 1)
    }
    async function deleteTicketInteraction(interaction) {
        let { member, guild, channel, message } = interaction
        let isTicket = db.prepare("SELECT * FROM tickets WHERE channelID=? AND status=?").get(channel.id, 1)
        if (!isTicket) return;
        interaction.deferUpdate()
        interaction.message.delete().catch(err => { })
        channel.send({
            embeds: Utils.embedBuilder(lang.Tickets.WillGetDeleted, [], {
                member: [member, "member"],
                guild: [guild, "guild"],
            })
        }).then(msg => {
            setTimeout(() => {
                channel.delete().catch(err => { })
            }, 5000);
        })
    }
    async function closeTicket(channel) {
        let isTicket = db.prepare("SELECT * FROM tickets WHERE channelID=? AND status=? OR channelID=? AND status=?").get(channel.id, 1, channel.id, 0)
        if (!isTicket) return;
        await db.prepare('UPDATE tickets SET status=?, closedAt=? WHERE channelID=? AND status=? OR channelID=? AND status=?').run(2, Math.round(new Date().getTime() / 1000), channel.id, 1, channel.id, 0)
        Utils.logWarn(`A ticket was closed! ID: ${isTicket.ID} Creator: ${isTicket.creatorID}`, "TICKET DELETED")
    }
    async function checkTickets() {
        const tickets = await db.prepare("SELECT * FROM tickets WHERE status=? OR status=?").all(0, 1)
        if (tickets.length < 1) return;
        tickets.forEach(ticket => {
            const guild = client.guilds.cache.get(ticket.guildID)
            if (!guild) {
                db.prepare('UPDATE tickets SET status=?, closedAt=? WHERE channelID=? AND status=? OR channelID=? AND status=?').run(2, Math.round(new Date().getTime() / 1000), ticket.channelID, 0, ticket.channelID, 1)
                return Utils.logWarn(`A ghost opened ticket, got deleted! [Guild not found] ${ticket.ID}`, "GHOST TICKET CLOSED");
            }
            const channel = guild.channels.cache.get(ticket.channelID)
            if (!channel) {
                db.prepare('UPDATE tickets SET status=?, closedAt=? WHERE channelID=? AND status=? OR channelID=? AND status=?').run(2, Math.round(new Date().getTime() / 1000), ticket.channelID, 0, ticket.channelID, 1)
                return Utils.logWarn(`A ghost opened ticket, got deleted! [Channel not found] ${ticket.ID}`, "GHOST TICKET CLOSED");
            }
        })
    }
    async function setCategory(ticket, value, interaction) {
        let { member, guild, channel, message } = interaction
        let category = config.Categories.find(a => a.Name.toLowerCase() == value.toLowerCase());
        if (!category) return interaction.reply({
            content: "I didn't find the category\n> Please contact an administrator!"
        });
        interaction.deferUpdate();
        let discordC = await Utils.getChannel(category.DiscordCategory, guild, "GUILD_CATEGORY", true)
        await db.prepare('UPDATE tickets SET category=? WHERE channelID=? AND status=?').run(category.Name, channel.id, 0)
        let Support = "";
        let permissions = [
            {
                id: guild.id,
                deny: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
            },
            {
                id: member.user.id,
                allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
            }
        ];
        category.Roles.forEach(async (r) => {
            let role = await Utils.getRole(r, guild, true)
            if (role) {
                Support += ` <@&${role.id}>`
                permissions.push({
                    id: role.id,
                    allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
                })
            }
        })
        await channel.permissionOverwrites.set(permissions);
        if (discordC) await channel.setParent(discordC.id)
        message.delete().catch(err => { })
        askQuestions(category, interaction, Support)
    }
    async function askQuestions(category, interaction, roles, otherChannel) {
        let { channel, guild, member, message } = interaction;
        if (otherChannel && otherChannel.id) channel = otherChannel;
        let questions = category.Questions
        if (!questions || !_.isArray(questions) || questions.length < 1) {
            return Utils.logError(`NO questions were provided in the category ${category.Name}`)
        }
        let responses = []
        async function sendQuestion(i) {
            let question = questions[i];
            if (!question && (!_.isString(question) || !_.isObject(question))) {
                if (i >= questions.length - 1) return completed();
                else return sendQuestion(++i)
            }
            if (_.isString(question)) {
                let info = {
                    type: "normal",
                    question: question,
                }
                question = info;
            } else if (_.isObject(question)) {
                let info = {
                    question: null,
                    type: null
                }
                let types = ["normal", "selection"]
                if (!question.type || !types.includes(question.type.toLowerCase())) {
                    Utils.logError(`The question ${i + 1} does not have a valid type!`)
                    if (i >= questions.length - 1) return completed();
                    else return sendQuestion(++i)
                }
                info.type = question.type.toLowerCase();
                if (!question.question || !_.isString(question.question)) {
                    Utils.logError(`The question ${i + 1} does not have a valid format!`)
                    if (i >= questions.length - 1) return completed();
                    else return sendQuestion(++i)
                }
                info.question = question.question;
                if (info.type == "normal") {
                    question = info;
                } else if (info.type == "selection") {
                    let options = question.options;
                    if (!options || !_.isArray(options) || options.length < 1) {
                        Utils.logError(`The question options in the question ${i + 1} does not follow a valid format!`)
                        if (i >= questions.length - 1) return completed();
                        else return sendQuestion(++i);
                    }
                    info.options = options;
                    question = info;
                }
            }
            if (question.type.toLowerCase() == "normal") {
                let msg = await channel.send({
                    embeds: Utils.embedBuilder(lang.Tickets.AskQuestions.Normal, [
                        { key: /{category-name}/g, value: category.Name },
                        { key: /{question}/g, value: question.question },
                        { key: /{index}/g, value: i + 1 },
                        { key: /{total}/g, value: questions.length },
                    ], {
                        member: [member, "member"],
                        guild: [guild, "guild"],
                    })
                })
                let response = await Utils.waitForResponse(member.id, channel).catch(err => { })
                if (!response) return;
                let content = response.content || "no content"
                let data = {
                    question: question.question,
                    content: content
                }
                if (response.attachments.size > 0) {
                    data.attachments = response.attachments;
                    await Utils.downloadAtts(response.attachments)
                }
                responses.push(data);
                if (i >= questions.length - 1) completed();
                else sendQuestion(++i)
            } else if (question.type.toLowerCase() == "selection") {
                let selections = {};
                let options = question.options;
                let map = [];
                let row = new MessageActionRow()
                    .addComponents(new MessageSelectMenu()
                        .setCustomId("questionOptions")
                        .setPlaceholder("Make a selection!")
                        .addOptions(options.map((option, i) => {
                            selections[`${option}`] = `${i + 1}`;
                            map.push(`\`${numbers.toEmoji(i + 1)}\` - **${option}**`)
                            return {
                                label: `${i + 1}`,
                                description: option,
                                value: `${i + 1}`,
                            }
                        }))
                    )

                let msg = await channel.send({
                    embeds: Utils.embedBuilder(lang.Tickets.AskQuestions.Selection, [
                        { key: /{category-name}/g, value: category.Name },
                        { key: /{question}/g, value: question.question },
                        { key: /{index}/g, value: i + 1 },
                        { key: /{options}/g, value: map.join("\n") },
                        { key: /{total}/g, value: questions.length },
                    ], {
                        member: [member, "member"],
                        guild: [guild, "guild"],
                    }),
                    components: [row]
                })
                let selection = await Utils.waitForSelection(Object.values(selections), member.id, msg).catch(err => { })
                if (!selection) return;
                let [value] = selection.values;
                selection.deferUpdate();
                msg.edit({
                    components: []
                })
                let data = {
                    question: question.question,
                    content: Object.keys(selections)[Object.values(selections).indexOf(value)]
                }
                responses.push(data);
                if (i >= questions.length - 1) completed();
                else sendQuestion(++i)
            }

        }

        sendQuestion(0)

        async function completed() {
            channel.bulkDelete(60).catch(err => { })
            const close = new MessageActionRow()
                .addComponents([Utils.buttonBuilder({
                    button: lang.Tickets.DefaultButtons.Close,
                    id: "closeTicket"
                })])

            let formated = responses.map(response => {
                return `${config.AnswersFormat.replace(/{Question}/g, response.question).replace(/{Answer}/g, response.content)}${response.attachments ? `\n${response.attachments.map(attch => { return `**${attch.name}** - \`Attachment\`` }).join("\n")}` : ``} `
            })
            // let attachments = [];
            await channel.send({
                embeds: Utils.embedBuilder(lang.Tickets.SendAnswers, [
                    { key: /{answers}/g, value: formated.join("\n\n") },
                    { key: /{category-name}/g, value: category.Name },
                    { key: /{category-emoji}/g, value: category.Emoji },
                    { key: /{category-description}/g, value: category.Description ? category.Description : "" },
                ], {
                    guild: [guild, "guild"],
                    member: [member, "member"]
                }),
                components: [close]
            })
            responses.forEach(async (info) => {
                if (info.attachments && info.attachments.size > 0) {
                    info.attachments.forEach(async (att) => {
                        try {
                            await channel.send({
                                content: `> **${att.name}**`,
                                files: [
                                    `./${att.name}`
                                ]
                            })
                            await fs.unlinkSync(`./${att.name}`)
                        } catch (error) {
                        }
                    })
                }

            })
        }
    }
    async function createTranscriptInteraction(interaction) {
        let { channel, guild, member } = interaction;
        let tChannel = await Utils.getChannel(config.Main.TranscriptChannel, guild, "GUILD_TEXT", true);
        if (!tChannel) {
            return interaction.reply({
                content: "I can no create a transcript because the transcript channel is not available!"
            })
        }
        // interaction.deferUpdate();
        let messages = await interaction.channel.messages.fetch({
            limit: 70
        }).catch(err => console.log(err));
        let transcript = await Utils.transcript(client, guild, channel, messages, interaction);
        let ticket = await db.prepare("SELECT * FROM tickets WHERE channelID=?").get(channel.id);
        if (ticket) {
            let creator = guild.members.cache.get(ticket.creatorID);
            tChannel.send({
                embeds: Utils.embedBuilder(lang.Tickets.Transcripts.Ticket, [
                    { key: /{ticket-id}/g, value: ticket.ID },
                    { key: /{ticket-channelId}/g, value: ticket.channelID },
                    { key: /{ticket-channelName}/g, value: channel.name },
                    { key: /{ticket-category}/g, value: ticket.category ? ticket.category : "no selected" },
                    { key: /{ticket-creatorId}/g, value: creator ? creator.id : ticket.creatorID },
                    { key: /{ticket-creatorTag}/g, value: creator ? creator.user.tag : "user not in the guild" },
                    { key: /{ticket-creatorUsername}/g, value: creator ? creator.user.username : "user not in the guild" },
                    { key: /{ticket-creatorIcon}/g, value: creator ? creator.user.displayAvatarURL({ dynamic: true }) ? creator.user.displayAvatarURL({ dynamic: true }) : "https://logos-marcas.com/wp-content/uploads/2020/12/Discord-Logo.png" : "user not in the guild" },
                ], {
                    guild: [guild, "guild"],
                    member: [member, "member"]
                }),
                files: [{
                    attachment: transcript,
                    name: `${channel.id}.html`
                }]
            })
        } else {
            tChannel.send({
                embeds: Utils.embedBuilder(lang.Tickets.Transcripts.Normal, [
                    { key: /{channel-name}/g, key: channel.name },
                    { key: /{channel-id}/g, key: channel.id },
                ], {
                    guild: [guild, "guild"],
                    member: [member, "member"]
                }),
                files: [{
                    attachment: transcript,
                    name: `${channel.id}.html`
                }]
            })
        }
        interaction.reply({
            content: `**Transcription created to the channel <#${channel.id}>**`,
            ephemeral: true
        })
    }
    /* ------------------------------------------------------------
                            Functions callers
    ------------------------------------------------------------ */
    checkTickets()
    setInterval(() => {
        checkTickets()
    }, 15000);
}