# Discord tickets bot

   _This is a discord bot for tickets, where you can give support to your guild users, this supports multiple categoies and multiple questions per category_

### Requirements 📋

# Hosting

   * [nodejs](https://nodejs.org) version 16.7 or higher ( latest STABLE version )
   * [python](https://python.org) version 3.8 or higher ( better-sqlite3 )

# Bot

   * [discord-applications](https://discord.com/developers/applications) create the discord client, and keep the token save 

# Configuration and Starting

   > If you are using replit you should use .env instead the main config.json | I DON'T RECOMMEND TO USE REPLIT BECAUSE IT HAS A LOT OF PROBLEMS WITH SQlite

   1. Complete the main data in [config.json](./botconfig/config.json), the discord client token
   2. In the [Ticket.yml](./botconfig/Tickets.yml) change the ticket system settings to your own settings especially where it mentions ROLES, CHANNELS, MEMBERS (According to your guild)
   3. Install all the modules using `npm install`
   4. Now you can open a cmd in the main directory and type `node .` || `npm start`
      * If you are on lunix (VPS) install [pm2](https://pm2.keymetrics.io/) then use `pm2 start index.js --name "tickets"`
         * This is to keep the proccess running if you close the terminal 

### Do u have problems? 😩

   _You can add me in discord `ElkinSantiana#0115` and i will try to give you all the help you need_

### COMMANDS / EVENTS HANDLER

   _The commands and events handler this bot uses was made by [Tomato6966](https://github.com/Tomato6966)_

### Formats

 * Custom Emojis
      - <a?:emojiName:emojiId> | <:Tickets:946176029083459715>
  
 * Embeds [Image-Reference](https://cdn.discordapp.com/attachments/825582131606585356/950250254379405353/unknown.png)
      - Color: "#00acff"
      - Title: 'Some title'
      - Author:
        - Name: 'Some name'
        - IconURL: "https://i.imgur.com/AfFp7pu.png"
      - Description: 'Some description here'
      - Thumbnail: "https://i.imgur.com/AfFp7pu.png"
      - Image: "https://i.imgur.com/AfFp7pu.png"
      - Timestamp: true
      - Footer:
        - Text: "Some footer text here"
        - IconURL: "https://i.imgur.com/AfFp7pu.png" 
      - Fields:
        - Name: 'Regular field title'
          Value: 'Some value here'   
        - Name: '\u200b'
			 Value: '\u200b'
			 Inline: false
        - Name: 'Inline field title'
			 Value: 'Some value here'
			 Inline: true
        - Name: 'Inline field title'
			 Value: 'Some value here'
			 Inline: true
        - Name: 'Inline field title'
			 Value: 'Some value here'
			 Inline: true

 * Buttons
      - style: PRIMARY || SECONDARY || SUCCESS || DANGER || LINK
      - disabled: true || false
      - label: any text
      - emoji: emoji
      - url: a valid url (Only for the style LINK)